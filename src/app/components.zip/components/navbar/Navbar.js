'use client'
import Image from 'next/image'
import logo from '../navbar/logo.png'
import { FaHeart } from "react-icons/fa";
import { HiShoppingBag } from "react-icons/hi2";


function Navbar() {
  return (
    <div className='pl-[200px] pr-[200px] pt-[15px] pb-[15px] flex justify-between'>
        <div><Image src={logo} width={100} height={100}/></div>
        <div className=' flex gap-10 font-semibold    mt-3'>
            <span className='text-[#84cc16]'>HOME</span>
            <span >SHOP</span>
            <span>PAGES</span>
            <span >BLOGS</span>
            <span >CONTACT</span>
            
        </div>
        <div className=' flex gap-3 pt-2 ' >
        <FaHeart />
        <HiShoppingBag />
        <span>items:<span className='font-semibold'>$150.00</span></span>
        </div>
      
    </div>
  )
}

export default Navbar
