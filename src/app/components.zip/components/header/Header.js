import React from 'react'
import { MdEmail } from "react-icons/md";
import { FaFacebookF } from "react-icons/fa";
import { IoLogoTwitter } from "react-icons/io";
import { FaLinkedinIn } from "react-icons/fa6";
import { FaPinterestP } from "react-icons/fa";
import { LiaFlagUsaSolid } from "react-icons/lia";

import { FaUser } from "react-icons/fa";
import { IoIosArrowDown } from "react-icons/io";

function Header() {
  return (
    <div className='bg-stone-200 pl-[180px] pr-[180px] pt-[10px] pb-[10px] flex justify-between ' >
      
      <div className='flex    divide-x-2 divide-gray-300'>

      <div className='flex gap-2 px-5  '>
     <MdEmail  /> <span className='text-xs' >hello@colorlib.com</span>
     </div>

     <div className='flex gap-2  px-5   '>
     <span className='text-xs' >Free Shipping for all Order of $99</span>
     </div>

     </div>

     <div className='flex    divide-x-2 divide-gray-300'>
      <div className='flex flex-row gap-2 px-5 '>
      <FaFacebookF />
      <IoLogoTwitter />
      <FaLinkedinIn />
      <FaPinterestP />
      </div>
      <div className='flex flex-row gap-2 px-5'>
      <LiaFlagUsaSolid />
      <span className='text-xs flex gap-2'>English <span><IoIosArrowDown  className='mt-1'/></span></span>
      </div>
      <div className='flex flex-row gap-2 px-5'>
      <FaUser />
      <span className='text-xs'>Login</span>
      </div>
     </div>


    </div>
  )
}

export default Header
