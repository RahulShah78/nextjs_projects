import Image from 'next/image'
import man from '../../../../public/feature-1.jpeg'


function Product() {
  return (
    <div className='pr-[200px] pl-[200px] mb-10 mt-10'>
    <div className='  divide-y-2  divide-blue-600 flex justify-center'>
      <h1 className='text-4xl font-bold '>From The Blog</h1>
    
    </div>

    <div className=' ml-[500px] w-[100px] h-[4px] bg-[#84cc16] mb-10  mt-3'>
    </div>

      <div className='flex justify-center gap-5'>
        <a href='#app' className='text-xl'>All</a>
        <a href='#app' className='text-xl'>Orange</a>
        <a href='#app' className='text-xl'>Fresh Meat</a>
        <a href='#app' className='text-xl'>Vegetable</a>
        <a href='#app' className='text-xl'>Fast Food</a>
        </div> 

        <div className='mt-10'>
            <div className='flex justify-between gap-[20px]'>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
            </div>

            <div className='flex justify-between gap-[20px] mt-10'>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
                <div>
                <Image src={man}  width={250} height={200} />
                <span className='flex justify-center mt-3'>Crab Pool Security</span>
                <span className='flex justify-center mt-4 font-bold'>$30.00</span>
                </div>
            </div>

            
        </div>
    </div>
  )
}

export default Product
