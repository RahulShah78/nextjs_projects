"use client"
import React from "react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import new_collections from '../../../../public/new_collections'
import Image from 'next/image';



export default function Sliders() {
  
  function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block",  background: "#ccc",textColor:"black", border:"2px solid",padding:"20px 2px", width:"30px", height:"60px", marginRight:"0px" }}
        onClick={onClick}
      />
    );
  }
  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: "block", background: "#ccc",textColor:"black", border:"2px solid",padding:"20px 2px", width:"30px", height:"60px", marginLeft:"-10px"}}
        onClick={onClick}
      />
    );
  }
  const settings = {
    dots: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 4,
    slidesToScroll: 1,
    
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />
  };
  return (
    <div className="pl-[110px] pr-[160px]">
    <div className="justify-center items-center w-[90%] mt-20  ml-[7%]">
    <Slider {...settings}>
      
      {
        new_collections.map((item)=>{
          return(
            <div key={item.id} className="flex  relative">
              <Image src={item.image} className="aspect-auto"/>
              <div className=" flex absolute bg-white text-black justify-center items-center mt-[-45px] mx-[52px] px-5 font-semibold">{item.name}</div>

            </div>
          )
        })
      }
    </Slider>
    </div>
    </div>
  );
}
