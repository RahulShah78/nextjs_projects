import { FaAngleDown } from "react-icons/fa";
import { IoCallSharp } from "react-icons/io5";
import Image from 'next/image'
import sabzi from '../slider/sabzi.png'
function Dropdown() {
  return (
    <div className="pl-[200px] pr-[200px] mt-4 pb-5">
      <div className="flex gap-8 ">
        <div className="col-lg-3">
          <details className="dropdown">
            <summary className="px-[30px] py-[10px] btn bg-[#84cc16] flex gap-10">
              All Department <FaAngleDown className="pt-1" />
            </summary>
            <ul className="px-[30px] py-[10px] shadow menu dropdown-content z-[1] bg-base-100 rounded-box ">
              <li className="mb-[15px] mt-3">
                <a href="Fresh Meat">Fresh Meat</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Vegetables</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Fruits & Nut Gifts</a>
              </li>

              <li className="mb-[15px]">
                <a href="Fresh Meat">Frsha Barries</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Ocean Foods</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Butter & Eggs</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Fastfood</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Fresh Onion</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Papaya & Crisps</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Oatmeal</a>
              </li>
              <li className="mb-[15px]">
                <a href="Fresh Meat">Fresh Banana</a>
              </li>
            </ul>
          </details>
        </div>
        <div className="col-lg-9  ">
          <div className="flex">
            <div className="px-[20px] py-[9px]  border-solid border-[1px] border-gray-300 flex divide-x-2  divide-gray-300 ">
              <div className="flex gap-5 ">
                <span className="font-bold">All Categories </span>{" "}
                <FaAngleDown className="pt-1" />
              </div>

              <div className="pl-[10px] flex">
                <input
                  type=" text"
                  placeholder="What do you needs?"
                  className=" w-[300px]"
                ></input>
              </div>
            </div>
            <button class="bg-[#84cc16]  text-white font-bold px-3">
              SUBSCRIBE
            </button>
            <div className="flex">
              <div className="bg-gray-300 py-4 px-4 rounded-full text-[#84cc16] ml-[30px]">
                <IoCallSharp />
              </div>

              <div className="flex flex-col ml-8">
                <span className="font-bold  ">+65 11.188.888</span>
                <span className="text-xs  text-gray-500 mt-2">
                  support 24/7 time
                </span>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <Image src={sabzi}  width={850} height={400}/>
          </div>

        </div>
      </div>
    </div>
  );
}

export default Dropdown;
