module.exports = {
    images: {
      
      remotePatterns: [
        {
          protocol: 'https',
          hostname: 'fakestoreapi.com',
          // You can specify other properties like port and pathname if needed
        },
        
      ],
      remotePatterns: [
        {
          protocol: 'https',
          hostname: 'fakestoreapi.com/img/',
          // You can specify other properties like port and pathname if needed
        },
      ],
    
      
    },
    env: {
      //RazorPay keys
      RAZORPAY_KEY:'rzp_test_FGEiPTZbiQzDhz',
      RAZORPAY_SECRET:'v7vZaJ6KZnTUboPjPu8Osmuf',
  },
  }