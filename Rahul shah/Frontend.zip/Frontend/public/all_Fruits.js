import p1_img from "./feature-1.jpeg";
import p2_img from "./feature-2.jpeg";
import p3_img from "./feature-3.jpeg";
import p4_img from "./feature-4.jpeg";
import p5_img from "./feature-5.jpeg";
import p6_img from "./feature-6.jpeg";
import p7_img from "./feature-1.jpeg";


let all_product = [
  {
    id: 1,
    name: "Crab Pool Security",
    category: "All",
    image: p1_img,
    price: 30.0,
    
  },
  {
    id: 2,
    name: "Crab Pool Security",
    category: "All",
    image: p2_img,
    price: 30.0,
    
  },
  {
    id: 3,
    name: "Crab Pool Security",
    category: "All",
    image: p3_img,
    price: 30.0,
    
  },
  {
    id: 4,
    name: "Crab Pool Security",
    category: "All",
    image: p4_img,
    price: 30.0,
  
  },
  {
    id: 5,
    name: "Crab Pool Security",
    category: "All",
    image: p5_img,
    price: 85.0,
   
  },
  {
    id: 6,
    name: "Crab Pool Security",
    category: "All",
    image: p6_img,
    price: 30.0,
    
  },


  {
    id: 7,
    name: "Crab Pool Security",
    category: "All",
    image: p1_img,
    price: 30.0,
   
 
  },
  {
    id: 8,
    name: "Crab Pool Security",
    category: "All",
    image: p7_img,
    price: 30.0,
    
  },

  {
    id: 25,
    name: "Crab Pool Security",
    category: "Oranges",
    image: p5_img,
    price: 30.0,
   
  },
  {
    id: 26,
    name: "Crab Pool Security",
    category: "Oranges",
    image: p4_img,
    price: 30.0,
    
  },
  {
    id: 27,
    name: "Crab Pool Security",
    category: "Oranges",
    image: p3_img,
    price: 30.0,
   
  },

  {
    id: 31,
    name: "Crab Pool Security",
    category: "Oranges",
    image: p1_img,
    price: 30.0,
    
  },
  {
    id: 32,
    name: "Crab Pool Security",
    category: "Fresh Meat",
    image: p6_img,
    price: 30.0,
    
  },
  {
    id: 33,
    name: "Crab Pool Security",
    category: "Fresh Meat",
    image: p7_img,
    price: 30.0,
    
  },
  {
    id: 34,
    name: "Crab Pool Security",
    category: "Fresh Meat",
    image: p1_img,
    price: 30.0,
    
  },
  {
    id: 35,
    name: "Crab Pool Security",
    category: "Fresh Meat",
    image: p3_img,
    price: 30.0,
    
  },
  {
    id: 36,
    name: "Crab Pool Security",
    category: "Vegetables",
    image: p1_img,
    price: 30.0,
    
  },
  {
    id: 37,
    name: "Crab Pool Security",
    category: "Vegetables",
    image: p2_img,
    price: 30.0,
    
  },
  {
    id: 38,
    name: "Crab Pool Security",
    category: "Vegetables",
    image: p3_img,
    price: 30.0,
    
  },
  {
    id: 39,
    name: "Crab Pool Security",
    category: "Fast Food",
    image: p4_img,
    price: 30.0,
  
  },
  {
    id: 40,
    name: "Crab Pool Security",
    category: "Fast Food",
    image: p6_img,
    price: 30.0,
    
  },
  {
    id: 41,
    name: "Crab Pool Security",
    category: "Fast Food",
    image: p7_img,
    price: 30.0,
    
  },
  {
    id: 42,
    name: "Crab Pool Security",
    category: "Fast Food",
    image: p1_img,
    price: 30.0,
    
  },

];

export default all_product;