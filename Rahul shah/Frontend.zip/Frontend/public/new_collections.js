import p1_img from "./feature-1.jpeg";
import p2_img from "./feature-2.jpeg";
import p3_img from "./feature-3.jpeg";
import p4_img from "./feature-4.jpeg";
import p5_img from "./feature-5.jpeg";
import p6_img from "./feature-6.jpeg";


let new_collections = [
  {
    id: 12,
    name: "Fresh Vegetables",
    image: p1_img,
   
  },
  {
    id: 13,
    name: "Fresh Fruits",
    image: p2_img,
   
  },
  {
    id: 14,
    name: "Fruits Chats",
    image: p3_img,

  },
  {
    id: 8,
    name: "Fruits Juices",
    image: p4_img,

  },
  {
    id: 15,
    name: " Fresh Vegetables",
    image: p5_img,

  },
  {
    id: 2,
    name: "Tasty Foods",
    image: p6_img,

  },
 
];

export default new_collections;